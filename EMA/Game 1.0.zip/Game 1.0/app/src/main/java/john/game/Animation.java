package john.game;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;

public class Animation
{
    private Bitmap[] frames;
    private int frameIndex;

    private boolean isPlaying = false;

    public boolean isPlaying()
    {
        return isPlaying;
    }

    public void play()
    {
        isPlaying = true;
        frameIndex = 0;
        lastFrame = System.currentTimeMillis();
    }

    public void stop()
    {
        isPlaying = false;
    }

    //time in between frames
    private float frameTime;

    private long lastFrame;

    public Animation(Bitmap[] frames, float animTime)
    {
        this.frames = frames;
        frameIndex = 0;

        frameTime = animTime/frames.length;
        lastFrame = System.currentTimeMillis();
    }

    public void draw(Canvas canvas, Rect dest)
    {
        if(!isPlaying)
        {
            return;
        }
        scaleRect(dest);

        canvas.drawBitmap(frames[frameIndex], null, dest, new Paint());
    }

    private void scaleRect(Rect rect)
    {
        float ratio = (float) (frames[frameIndex].getWidth())/frames[frameIndex].getHeight();
        if(rect.width() > rect.height())
        {
            rect.left = rect.bottom -  (int)(rect.height() * ratio);
        }
        else
        {
            rect.top = rect.bottom - (int) (rect.width() * (1/ratio));
        }
    }


    public void update()
    {
        if(!isPlaying)
        {
            return;
        }

        if(System.currentTimeMillis() - lastFrame > frameTime*1000)
        {
            //go to next frame
            frameIndex++;
            frameIndex = frameIndex >= frames.length ? 0 : frameIndex;
            lastFrame = System.currentTimeMillis();
        }
    }
}
