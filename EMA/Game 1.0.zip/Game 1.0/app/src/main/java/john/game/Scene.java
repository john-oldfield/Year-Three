package john.game;

import android.graphics.Canvas;
import android.view.MotionEvent;

public interface Scene
{
    public void update();
    public void draw(Canvas canvas);
    //Tells Scene manager to switch active screen
    public void terminate();
    public void receiveTouch(MotionEvent event);
}
