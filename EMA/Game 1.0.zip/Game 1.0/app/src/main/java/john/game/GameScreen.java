package john.game;

import android.content.Context;
import android.graphics.Canvas;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class GameScreen extends SurfaceView implements SurfaceHolder.Callback
{
    private MainThread mainThread;
    private SceneManager mgr;

    public GameScreen(Context context)
    {
        super(context);

        getHolder().addCallback(this);

        //Make current context equal to this context
        Constants.CURRENT_CONTEXT = context;

        mainThread = new MainThread(getHolder(), this);
        mgr = new SceneManager();

        //change view focus
        setFocusable(true);
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder)
    {
        mainThread = new MainThread(getHolder(), this);
        Constants.INIT_TIME = System.currentTimeMillis();
        mainThread.setRunning(true);
        mainThread.start();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height)
    {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder)
    {
        boolean retry = true;
        while(retry)
        {
            try
            {
                //stop game loop
                mainThread.setRunning(false);
                //finish running thread then stop
                mainThread.join();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }

            retry = false;
        }
    }

    @Override
    //Handle touch events
    public boolean onTouchEvent(MotionEvent event)
    {
        mgr.receiveTouch(event);
        return true;
    }

    //Update game frame by frame
    public void update()
    {
        mgr.update();
    }

    //Display Game
    @Override
    public void draw(Canvas canvas)
    {
        super.draw(canvas);
        mgr.draw(canvas);
    }
}
