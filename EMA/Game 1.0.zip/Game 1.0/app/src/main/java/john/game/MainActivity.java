package john.game;

import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity
{
    MediaPlayer music;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        //Hide Status Bar
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //Hide Activity Title
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);

        //Store screen dimensions in constants class
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        Constants.SCREEN_WIDTH = dm.widthPixels;
        Constants.SCREEN_HEIGHT = dm.heightPixels;

        setContentView(new GameScreen(this));

        music = MediaPlayer.create(MainActivity.this, R.raw.music);
        music.setLooping(true);
        music.start();
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        music.pause();
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        music.start();
    }
}
