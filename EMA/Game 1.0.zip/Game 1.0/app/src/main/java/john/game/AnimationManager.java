package john.game;

import android.graphics.Canvas;
import android.graphics.Rect;

public class AnimationManager
{
    private Animation[] anims;
    private int animIndex = 0;

    public AnimationManager(Animation[] anims)
    {
        this.anims = anims;
    }

    public void playAnim(int index)
    {
        for(int i = 0; i < anims.length; i++)
        {
            if(i == index)
            {
                //if not already playing
                if(!anims[index].isPlaying())
                {
                    anims[i].play();
                }
            }
            else
            {
                anims[i].stop();
            }
        }
        animIndex = index;
    }

    public void draw(Canvas canvas, Rect rect)
    {
        if(anims[animIndex].isPlaying())
        {
            anims[animIndex].draw(canvas, rect);
        }
    }

    public void update()
    {
        if(anims[animIndex].isPlaying())
        {
            anims[animIndex].update();
        }
    }
}
