package john.game;

import android.graphics.Canvas;
import android.view.SurfaceHolder;

public class MainThread extends Thread
{
    //Cap fps for game to avoid unecessary calls to game loop
    public static final int MAX_FPS = 30;
    private double avgFPS;
    private SurfaceHolder surfaceHolder;
    private GameScreen gameScreen;
    private boolean running;
    public static Canvas canvas;

    public void setRunning(boolean running)
    {
        this.running = running;
    }

    public MainThread(SurfaceHolder surfaceHolder, GameScreen gameScreen)
    {
        super();
        this.surfaceHolder = surfaceHolder;
        this.gameScreen = gameScreen;
    }

    @Override
    public void run()
    {
        long startTime;
        //1000 Ms = 1 Second
        long timeMillis = 1000/MAX_FPS;
        long waitTime;
        int frameCount = 0;
        int totalTime = 0;
        long targetTime = 1000/MAX_FPS;

        while(running)
        {
            //Get System Time
            startTime = System.nanoTime();
            canvas = null;

            try
            {
                //Create surface area to write to and prevent simultaneous accessing of code
                canvas = this.surfaceHolder.lockCanvas();

                // prevents concurrent access to a block of code
                synchronized (surfaceHolder)
                {
                    this.gameScreen.update(); //Handle Changes in Game
                    this.gameScreen.draw(canvas); //Draw changes
                }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
            finally
            {
                if(canvas != null)
                {
                    try
                    {
                        surfaceHolder.unlockCanvasAndPost(canvas);
                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
            }
            //Divide by 1M to get time in millis
            timeMillis = (System.nanoTime() - startTime)/1000000;
            waitTime = targetTime - timeMillis;
            try
            {
                //If frame finishes before target time
                if(waitTime > 0)
                {
                    //Pause thread for the wait time (Capping frame rate)
                    this.sleep(waitTime);
                }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }

            //total time after sleep
            totalTime += System.nanoTime() - startTime;
            frameCount++;
            if(frameCount == MAX_FPS)
            {
                //calculate average fps
                avgFPS = 1000/((totalTime/frameCount)/1000000);

                //Reset Values
                frameCount = 0;
                totalTime = 0;

                //Test to see FPS
                System.out.println(avgFPS);
            }
        }
    }
}
