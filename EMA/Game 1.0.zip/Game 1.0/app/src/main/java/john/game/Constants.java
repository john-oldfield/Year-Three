package john.game;

import android.content.Context;

public class Constants
{
    //Screen dimensions
    public static int SCREEN_WIDTH;
    public static int SCREEN_HEIGHT;

    public static Context CURRENT_CONTEXT;

    //Time app initialized (for backing out of game via home etc)
    public static long INIT_TIME;
}
