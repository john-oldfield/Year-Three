package john.game;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.view.MotionEvent;

public class GameScene implements Scene
{
    private Player player;
    private Rect r = new Rect();

    private Point playerPoint;
    private WallManager wallManager;

    private boolean playerMoving = false;
    private boolean gameOver = false;
    private long gameOverTime;

    public GameScene()
    {
        player = new Player(new Rect(100, 100, 200, 200), Color.rgb(255, 0, 0));
        //Set player starting point to middle and 3/4 down screen
        playerPoint = new Point(Constants.SCREEN_WIDTH/2, 3*Constants.SCREEN_HEIGHT/4);
        player.update(playerPoint);

        int r = (int)(Math.random()*256);
        int g = (int)(Math.random()*256);
        int b = (int)(Math.random()*256);

        wallManager = new WallManager(250, 500, 75, Color.rgb(r,g,b));
    }

    private SceneManager mgr;

    @Override
    public void update()
    {
        //if game isnt over continue updating
        if(!gameOver)
        {
            player.update(playerPoint);
            wallManager.update();

            //if player hits wall make game over
            if(wallManager.playerCollide(player))
            {
                gameOver = true;
                gameOverTime = System.currentTimeMillis();
            }
        }
    }

    @Override
    public void draw(Canvas canvas)
    {
        //Set background color to white
        canvas.drawColor(Color.WHITE);

        //Draw Player and Walls
        player.draw(canvas);
        wallManager.draw(canvas);

        if(gameOver)
        {
            Paint p  = new Paint();
            p.setTextSize(100);
            p.setColor(Color.RED);
            drawCenterText(canvas, p, "GAME OVER! TAP TO RETRY");
        }
    }

    @Override
    public void terminate()
    {
        mgr.ACTIVE_SCENE = 0;
    }

    //function to reset game upon failure
    public void reset()
    {
        //Move player back to start position
        playerPoint = new Point(Constants.SCREEN_WIDTH/2, 3*Constants.SCREEN_HEIGHT/4);
        player.update(playerPoint);
        //Reset walls
        int r = (int)(Math.random()*256);
        int g = (int)(Math.random()*256);
        int b = (int)(Math.random()*256);

        wallManager = new WallManager(250, 500, 75, Color.rgb(r,g,b));
        playerMoving = false;
    }

    @Override
    public void receiveTouch(MotionEvent event)
    {
        switch(event.getAction())
        {
            //Get player point on action
            case MotionEvent.ACTION_DOWN:
                if(!gameOver && player.getRectangle().contains((int) event.getX(),
                        (int) event.getY()))
                {
                    playerMoving = true;
                }
                //Game over screen last 2 seconds
                if(gameOver && System.currentTimeMillis() - gameOverTime >= 1500)
                {
                    reset();
                    gameOver = false;
                }
                break;
            case MotionEvent.ACTION_MOVE:
                if(!gameOver && playerMoving)
                {
                    //Move character with movements
                    playerPoint.set((int) event.getX(), (int) (event.getY() - 200));
                }
                break;
            case MotionEvent.ACTION_UP:
                playerMoving = false;
                break;

        }
    }

    //Method to draw text in center of screen
    private void drawCenterText(Canvas canvas, Paint paint, String text) {
        paint.setTextAlign(Paint.Align.LEFT);
        canvas.getClipBounds(r);
        int cHeight = r.height();
        int cWidth = r.width();
        paint.getTextBounds(text, 0, text.length(), r);
        float x = cWidth / 2f - r.width() / 2f - r.left;
        float y = cHeight / 2f + r.height() / 2f - r.bottom;
        canvas.drawText(text, x, y, paint);
    }
}
