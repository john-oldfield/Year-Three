package john.game;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import java.util.ArrayList;


public class WallManager
{
    private ArrayList<Wall> walls; // Lowest Index is the highest wall on screen
    private int wallGap; // GAP TO GO THROUGH
    private int playerGap; //GAP BETWEEN WALLS
    private int wallHeight;
    private int color;

    private long startTime;
    private long initTime; // Time class was initialized

    private int score = 0;

    public WallManager(int wallGap, int playerGap, int wallHeight, int color)
    {
        this.wallGap = wallGap;
        this.playerGap = playerGap;
        this.wallHeight = wallHeight;
        this.color = color;

        startTime = initTime = System.currentTimeMillis();

        walls = new ArrayList<>();
        populateWalls();
    }

    //Detect if player is hitting a wall
    public boolean playerCollide(Player player)
    {
        for(Wall w : walls)
        {
            if(w.playerCollide(player))
            {
                return true;
            }
        }
        return false;
    }

    private void populateWalls()
    {
        //Start making walls off screen
        int curY  = -5*Constants.SCREEN_HEIGHT/4;

        //Keep generating walls
        while(curY < 0)
        {
            //Ensure always a space to go through
            int xStart = (int)(Math.random()*(Constants.SCREEN_WIDTH - wallGap));
            walls.add(new Wall(wallHeight, color, xStart, curY, wallGap));

            curY += wallHeight + playerGap;
        }
    }

    public void update()
    {
        //Reset time if user comes back on app after being away via home
        // (Stops walls falling in background)
        if(startTime < Constants.INIT_TIME)
        {
            startTime = Constants.INIT_TIME;
        }
        //Time since last frame
        int elapsedTime = (int) (System.currentTimeMillis() - startTime);
        startTime = System.currentTimeMillis();

        //Speed of falling walls, Square Root is used to speed up game over time
        float speed = (float)(Math.sqrt(1 + (startTime - initTime)/3000.0))*Constants.SCREEN_HEIGHT/(10000.0f);
        for (Wall w: walls)
        {
            w.increaseY(speed * elapsedTime);
        }
        //Generate new wall once it has gone off screen
        if(walls.get(walls.size() - 1).getRectangle().top >= Constants.SCREEN_HEIGHT)
        {
            int xStart = (int)(Math.random()*(Constants.SCREEN_WIDTH - wallGap));
            walls.add(0, new Wall(wallHeight, color, xStart,
                    walls.get(0).getRectangle().top - wallHeight - playerGap, wallGap));
            walls.remove(walls.size() - 1);
            //+1 Score each time wall is passed
            score++;
        }
    }

    public void draw(Canvas canvas)
    {
        for(Wall w : walls)
        {
            w.draw(canvas);
        }
        Paint p = new Paint();
        p.setTextSize(100);
        p.setColor(Color.RED);
        //p.descent - p.ascent distance between bottom and top of text
        canvas.drawText("Distance: " + score + "m", 50, 50 + p.descent() - p.ascent(), p);
    }
}
