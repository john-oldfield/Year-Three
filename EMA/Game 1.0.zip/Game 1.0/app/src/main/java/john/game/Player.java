package john.game;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Point;
import android.graphics.Rect;

public class Player implements GameObject
{
    private Rect rectangle;

    //Animation Variables
    private Animation idle;
    private Animation walkRight;
    private Animation walkLeft;
    private AnimationManager animManager;

    public Player(Rect rectangle, int color)
    {
        this.rectangle = rectangle;

        BitmapFactory bf = new BitmapFactory();
        Bitmap idlePlayer = bf.decodeResource(Constants.CURRENT_CONTEXT.getResources(), R.drawable.player);
        Bitmap walkR = bf.decodeResource(Constants.CURRENT_CONTEXT.getResources(), R.drawable.player1);
        Bitmap walkL = bf.decodeResource(Constants.CURRENT_CONTEXT.getResources(), R.drawable.player2);

        idle = new Animation(new Bitmap[]{idlePlayer}, 2);
        walkRight = new Animation(new Bitmap[]{walkR, walkL}, 0.5f);

        //Flip images to face other direction
        Matrix m = new Matrix();
        m.preScale(-1, 1);
        walkR = Bitmap.createBitmap(walkR, 0, 0, walkR.getWidth(), walkR.getHeight(), m, false);
        walkL = Bitmap.createBitmap(walkL, 0, 0, walkL.getWidth(), walkL.getHeight(), m, false);

        walkLeft = new Animation(new Bitmap[]{walkR, walkL}, 0.5f);

        animManager = new AnimationManager(new Animation[]{idle, walkRight, walkLeft});
    }

    public Rect getRectangle()
    {
        return rectangle;
    }

    @Override
    public void draw(Canvas canvas)
    {
        animManager.draw(canvas, rectangle);
    }

    @Override
    public void update()
    {
        animManager.update();
    }

    //Move player to different positions
    public void update(Point point)
    {
        float oldLeft = rectangle.left;

        //Set point to center
        rectangle.set(point.x - rectangle.width()/2, point.y - rectangle.height()/2,
                point.x + rectangle.width()/2, point.y + rectangle.height()/2);

        //calculate which animation to play
        //Not walking
        int status = 0;
        if(rectangle.left - oldLeft > 5)
        {
            //Walking Right
            status = 1;
        }
        else if(rectangle.left - oldLeft < -5)
        {
            //Walking left
            status = 2;
        }
        animManager.playAnim(status);
        animManager.update();
    }
}
